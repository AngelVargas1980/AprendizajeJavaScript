/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
function signin()
{
container.classList.remove('right-panel-active');
}
function signup()
{
container.classList.add('right-panel-active');
}

function showMessage(){
    
};